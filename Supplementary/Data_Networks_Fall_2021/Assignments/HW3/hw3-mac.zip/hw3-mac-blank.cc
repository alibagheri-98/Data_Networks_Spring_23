#include "ns3/core-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/yans-wifi-channel.h"
#include "ns3/constant-position-mobility-model.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/on-off-helper.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/mobility-module.h"
#include "ns3/ipv4-flow-classifier.h"
#include "ns3/applications-module.h"
#include "ns3/animation-interface.h"

using namespace ns3;

int main(int argc, char *argv[])
{
    uint32_t nStation;
    uint16_t cbrPort;
    uint32_t packetSize;

    // Creating Command Line Options
    CommandLine cmd;
    cmd.AddValue ("nStation", "Number of stations in the access point vicinity", nStation);
    cmd.AddValue ("Port", "The port used by OnOff application", cbrPort);
    cmd.AddValue ("PacketSize", "Size of each UDP packet", packetSize);
    cmd.Parse (argc, argv);

    // Creating Contention Window Parameters
    /** \todo **/


    // Creating AP and STA Nodes
    NodeContainer apNodes, staNodes;
    /** \todo **/


    // Create YansWifiChannelHelper & YansWifiPhyHelper
    YansWifiChannelHelper wifiChannel = YansWifiChannelHelper::Default ();
    YansWifiPhyHelper wifiPhy = YansWifiPhyHelper::Default ();
    wifiPhy.SetChannel (wifiChannel.Create ());

    // Create WifiHelper (Use WIFI_PHY_STANDARD_80211g and IdealWifiManager)
    /** \todo **/


    // Create WifiMacHelper
    WifiMacHelper wifiMac;

    // Install wifi On Stations
    /** \todo **/


    // Install wifi On Access Points
    /** \todo **/


    // Create MobilityHelper and set parameters
    /** \todo **/


    // Install Mobility On APs And Stations
    /** \todo **/


    // Install TCP/IP Stack On All Nodes
    InternetStackHelper internet;
    internet.InstallAll ();

    // Assign IP Addresses
    /** \todo **/


    // Create OnOffHelper and Set Attributes
    /** \todo **/


    // Start OnOff Applications
    /** \todo **/


    // Installing Sink Application On The Destination
    PacketSinkHelper sink ("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), cbrPort));
    ApplicationContainer sinkApps = sink.Install (staNodes);

    // Start Sink Applications
    sinkApps.Stop (Seconds (10.0));
    sinkApps.Start (Seconds (0.0));

    // Enable Pcap Tracing + Create NetAnim File
    /** \todo **/


    // Creating Install FlowMonitor On all nodes
    /** \todo **/


    // Starting Simulation + Destory when over
    Simulator::Stop (Seconds (10.0));
    Simulator::Run ();
    Simulator::Destroy ();

    // Print Out The Summary Of Flows
    /** \todo **/

    
    return 0;
}
